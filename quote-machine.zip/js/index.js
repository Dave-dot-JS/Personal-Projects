function setBackground() {
  var colors = ['#cc0099','#cc0000','#99e600','#66ff66','#00e673','#00cc99','#cc00cc','#8A2BE2', '#0088cc', '#6666ff', '#a64dff', '#ff1065'];
  return colors[Math.floor(Math.random() * colors.length)] + 'cc';
}

function generateQuote() {
  var quotes = [
['"Time\s up, let\'s do this."', ' - Leeroy Jenkins'],
                
['"If at first you don\'t succeed, it\'s probably because you weren\'t good enough in the first place."', ' - Grixs'],
                
['"You can be replaced."', ' - Mayur Gala'],
                
['"It probably will get worse."', ' - James Douglas'],
                
['"Dream. Only to escape the miserable reality of your life."', ' - Dominik Schröder'],
                
['"Don\'t cry because it\'s over, smile because if you don\'t everyone will ask you what\'s wrong."', ' - Alex Wigan'],
                
['"Burn it. Burn it all."', ' - Anonymous'],
                
['"If you can stay calm, while all around you is chaos…then you probably haven\’t completely understood the seriousness of the situation."', ' - Alexander / via positivesharing.com'],
                
['"You could probably be doing better..."', ' - The World'],

['"Every corpse on Mount Everest was at one time a very, very motivated person."', ' - by lukianp / via reddit.com'],
                
['"Those who doubt your ability probably have a valid reason."', ' - Luke Pamer'],
                
['"Life is not a fairytale. If you lose your shoe at midnight, you\'re drunk"', ' - Aleksandra Boguslawska'],
               
['"Whenever you feel insignificant, just remember...you are."', ' - Anonymous'],
               
['"Ew."', ' - everyone']
    ];
  
  var quoteArray = quotes[Math.floor(Math.random() * quotes.length)];
  var quote = quoteArray[0];
  var author = quoteArray[1];
  return quoteArray;
};

$(document).ready(function() {
 $(".btn-primary").bind("click",function() {
    $("body").css("background-color", setBackground())
  });
  
  $("#generate").bind("click", function() {
    var quoteGenerated = generateQuote()
    var urlQuote = 'http://twitter.com/intent/tweet?text=' + encodeURIComponent(quoteGenerated[0] + quoteGenerated[1])
    $("#newQuote").html(quoteGenerated[0] + '<br /><h5><em>' + quoteGenerated[1] + '</em></h5>')
    $("#tweet").attr('href', urlQuote)
  });  
});

//https://twitter.com/intent/tweet?text=