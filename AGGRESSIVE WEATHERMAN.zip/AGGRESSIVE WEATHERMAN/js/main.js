const forecast = document.getElementById('forecast-description');
const forecastTemp = document.getElementById('forecast-temp');
let temp;

function displayTemp(temperature) {
	if (temp <= 10) {
		forecast.innerText = 'IT\'S COLD!';
		forecast.style.animation = "cold 0.5s linear infinite";
		forecastTemp.style.animation = "cold 0.5s linear infinite";
	} else if (temp >= 25) {
		forecast.innerText = 'IT\'S STEAMY!';
		forecast.style.animation = "hot 0.5s linear infinite";
		forecastTemp.style.animation = "hot 0.5s linear infinite";
	} else {
		forecast.innerText = 'IT\'S AVERAGE YO!';
		forecast.style.animation = "avg 0.5s linear infinite";
		forecastTemp.style.animation = "avg 0.5s linear infinite";
	};
}

document.getElementById("set-temp").addEventListener("click", function(){
	temp = prompt('WHAT\'S THE TEMPERATURE?!');
	forecastTemp.innerHTML = temp;
	displayTemp(temp);
});
