A Pen created at CodePen.io. You can find this one at https://codepen.io/grixs/pen/MQqwOb.

 This is not the greatest page in the world....it is just a tribute 